"""Generate the LaTeX results table of the manuscript from results/exp3_protocols.json (provenance)."""
import json, os
here = os.path.dirname(os.path.abspath(__file__)); e = json.load(open(os.path.join(here, "results", "exp3_protocols.json")))
lines = [r"\begin{tabular}{rrrrrrrcc}", r"\toprule",
         r"$N$ & $a$ & $r$ & A & B & C1 & C2 & succ.\ A & succ.\ B \\", r"\midrule"]
for row in e["rows"]:
    lines.append(f"{row['N']} & {row['a']} & {row['r']} & {row['A']['cost_mean']:.0f} & {row['B']['cost_mean']:.0f} & {row['C1']['cost_mean']:.0f} & {row['C2']['cost_mean']:.0f} & {row['A']['success_rate']:.2f} & {row['B']['success_rate']:.2f} \\\\")
lines += [r"\midrule", "fit & & & " + " & ".join(f"${e['fits'][k]['prefactor']:.1f}\\,r^{{{e['fits'][k]['exponent']:.2f}}}$" for k in ["A","B","C1","C2"]) + r" & & \\", r"\bottomrule", r"\end{tabular}"]
open(os.path.join(here, "..", "table_protocols.tex"), "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
