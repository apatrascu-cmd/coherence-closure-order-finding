Title: Reproducibility code and data
Description: Python source, numerical outputs, figures and controls reproducing the closure-selection analysis, adaptive order-finding protocols and finite-dephasing crossover.

Python source is supplied as plain text (.py.txt). Restore each .py filename by removing the final .txt suffix before using the commands below. File contents are unchanged.

# Supplementary code: closure-selection order finding

Reproduces every deterministic control, figure, and scaling analysis in the manuscript. Use Python 3 (>= 3.8) and
install the two dependencies listed in `requirements.txt`. No absolute paths are used. Run from this directory:

    python3 run_all.py

Run order and content (each script prints PASS/FAIL controls and writes `results/*.json`, `figs/*.pdf|png`):

1. `exp1_closure_dynamics.py` — class-level closure dynamics. Controls: the hand-iterated example of the
   original submission (Q1 = 1/2, Q2 = 27/34); steps to P0 >= 0.99 within the corollary bound for r = 4 ... 65536;
   the closed-form basin threshold Q* against a bisection on the numerically observed basin. Figure 1.
2. `exp2_diagonal_filter.py` — cumulative acceptance probability of the diagonal (two-copy) closure filter versus r,
   against the bound P0(0) + (1-P0(0)) exp(-gamma t). Figure 2.
3. `exp3_protocols.py` — protocols A (coherent closure loop, predicate access), B (coherent closure loop with relational
   memory), C1 (classical memoryless sampling), C2 (classical birthday). Controls: full state-vector evolution and
   end-to-end recovery of r with no use of r anywhere (dense diagonalisation, M = 2048) against the two-level formula;
   every recovered r equals the brute-force order; fitted exponents. Figure 3 and Table 1.
   Simulator note: for the scaling runs the post-evolution distribution is known in closed form (two-level theorem,
   verified by the control), and samples are drawn from it directly; the controller never sees r.
4. `exp4_boolean_qft.py` — Fourier readout of the Boolean defect predicate: P(useful peak) = (2/r)(1-1/r).
5. `exp5_dephasing.py` — exact permutation-reduced Lindblad dynamics for local and sector dephasing, including
   controls against the full density matrix, the unitary formula, and the classical large-dephasing limit. Writes
   `results/exp5_dephasing.json`; `plot_dephasing.py` regenerates Figure 4 from that machine-readable result.

Runtime on a laptop: roughly ten minutes in total; the dephasing scan and dense state-vector control dominate.
Random seeds are fixed. Deterministic controls should reproduce to the printed tolerances. Monte Carlo means are
finite-sample estimates and may vary at the quoted statistical level across numerical-library versions; the scaling
conclusions are checked from the regenerated output rather than by requiring bit-for-bit identity.

Note: `make_table.py` regenerates `../table_protocols.tex` from `results/exp3_protocols.json`; the same tabular is
inlined in the manuscript (`nongate_order_finding_qic.tex`) so that the submission compiles from one main TeX file.
