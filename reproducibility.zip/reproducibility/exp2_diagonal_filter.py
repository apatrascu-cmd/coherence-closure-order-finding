"""Experiment 2: any realization of closure selection that is diagonal in the configuration basis
(dissipative defect suppression, the two-copy selective map, the memory-feedback surrogate) is a classical
rejection sampler. Cumulative success probability of the trace-non-increasing two-copy filter after t steps
versus r; theorem bound: success <= P0(0) + (1-P0(0)) e^{-gamma t}, and success <= P0(0)/(min weight of the
target class)... The simulation tracks the exact per-class cumulative acceptance.
"""
import numpy as np
from common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
T = Timer("exp2")
gamma, beta = np.log(3), np.log(2); kappa = np.exp(beta) - 1
rows = []
for k in range(2, 21, 2):
    r = 2 ** k; D = np.zeros(r); D[1:] = 1
    P = np.full(r, 1 / r); cum = np.ones(r); t = 0
    while P[0] < 0.99:
        g = np.exp(-gamma * D) * (np.exp(-beta) * (1 + kappa * P)) ** 2     # rescaled so that all weights <= 1
        cum *= g
        w = np.exp(-gamma * D) * (1 + kappa * P) ** 2; P = P * w / np.sum(P * w)   # squared-kernel (two-copy) dynamics
        t += 1
    succ = float(np.sum(np.full(r, 1 / r) * cum)); bound = 1 / r + (1 - 1 / r) * np.exp(-gamma * t)
    rows.append({"r": r, "steps": t, "success": succ, "bound": bound, "P0_final": float(P[0])})
    print(f"r=2^{k:2d}: steps={t:3d}  cumulative success={succ:.3e}  bound={bound:.3e}  1/r={1/r:.3e}")
ok = all(row["success"] <= row["bound"] * (1 + 1e-12) for row in rows)
print("control: success <= bound for all r:", "PASS" if ok else "FAIL")
save_json("exp2_diagonal_filter.json", {"gamma": gamma, "beta": beta, "rows": rows, "control_bound": ok})
fig, ax = plt.subplots(figsize=(4.6, 3.4))
rs = np.array([x["r"] for x in rows]); ax.loglog(rs, [x["success"] for x in rows], "o-", label="cumulative acceptance (simulation)")
ax.loglog(rs, [x["bound"] for x in rows], "k--", label=r"bound $P_0^{(0)}+(1-P_0^{(0)})e^{-\gamma t}$")
ax.loglog(rs, 1 / rs, ":", c="gray", label="$1/r$")
ax.set_xlabel("number of sectors $r$"); ax.set_ylabel("probability that the filter accepts"); ax.legend(fontsize=7.5)
ax.set_title("Diagonal (two-copy) closure filter", fontsize=10)
fig.tight_layout(); fig.savefig(os.path.join(FIGS, "fig2_diagonal_filter.pdf")); fig.savefig(os.path.join(FIGS, "fig2_diagonal_filter.png"), dpi=150)
T.lap("done; CONTROL " + ("PASS" if ok else "FAIL"))
