"""Experiment 3: the order-finding protocols and their cost scaling with the order r.

Protocols (E = 1 sets the unit of evolution time; cost = evolution time + classical oracle evaluations):
  A  coherent closure loop, predicate-level access: H = Pi_F + |s><s| on X = {1..M-1}, F = {d : a^d = 1 mod N};
     controller keeps a horizon T (memory), draws tau ~ U[0,T], measures, keeps T on success, T <- lambda T on failure;
     stops after s defect-free samples; r_hat = gcd(samples).
  B  coherent closure loop with relational memory (value-level access): memory of k sampled (x_i, a^{x_i} mod N);
     predicate "a^x mod N is in memory and x not in memory"; k doubles when the search fails within budget 4k.
  C1 classical memoryless predicate sampling.
  C2 classical relational memory (birthday collisions of stored values).
Controls: (i) full state-vector evolution (dense diagonalisation, no use of r anywhere) versus the two-level
formula, and end-to-end recovery of r from state-vector measurements; (ii) every recovered r equals the
brute-force order; (iii) fitted exponents reported against 1/2, 1/3, 1, 1/2.
"""
import numpy as np, math, json, sys
from functools import reduce
def gcd_all(v): return reduce(math.gcd, v)
def lcm2(a, b): return a * b // math.gcd(a, b)
from common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
T = Timer("exp3"); rng = np.random.default_rng(12345)
LAM = 6 / 5; S = 8; E = 1.0

def order_semiprime(a, p, q):
    return lcm2(order(a % p, p), order(a % q, q))

def instances_semiprime(targets, seed=1):
    rng = np.random.default_rng(seed); primes = [p for p in range(3, 400) if is_prime(p)]; pool = {}
    for _ in range(40000):
        p, q = [int(v) for v in rng.choice(primes, 2, replace=False)]; N = p * q
        a = int(rng.integers(2, N - 1))
        if math.gcd(a, N) != 1: continue
        r = order_semiprime(a, p, q); pool.setdefault(r, (N, a))
    keys = np.array(sorted(pool)); out = []
    for rt in targets:
        r = int(keys[np.argmin(np.abs(np.log(keys) - np.log(rt)))])
        if all(r != o[2] for o in out): N, a = pool[r]; out.append((N, a, r))
    return out

class Instance:
    def __init__(self, N, a, r, M=None):
        self.N, self.a, self.r = N, a, r
        self.M = M or 2 ** int(np.ceil(2 * np.log2(N)))          # Shor-type window, M >= N^2
        self.m = (self.M - 1) // r                                # |F|, F = multiples of r in [1, M-1]
        self.x = np.sqrt(self.m / (self.M - 1))
    def g(self, d): return pow(self.a, int(d), self.N) == 1        # defect-free predicate (the only oracle)
    def f(self, d): return pow(self.a, int(d), self.N)

# ---------------- Protocol A -----------------
def protocol_A(inst, rng, s=S):
    M, m, x, r = inst.M, inst.m, inst.x, inst.r
    Tm = 1.0; cost = 0.0; samples = []; first = None; rounds = 0
    while len(samples) < s:
        tau = rng.uniform(0, Tm); cost += tau + 1; rounds += 1      # evolution time plus one predicate evaluation
        P = two_level_prob(x, E, tau)
        if rng.random() < P:                       # measurement lands in F: uniform over multiples of r (simulator shortcut)
            d = int(rng.integers(1, m + 1)) * r
        else:
            while True:
                d = int(rng.integers(1, M))
                if not inst.g(d): break
        if inst.g(d):
            samples.append(d)
            if first is None: first = cost
        else:
            Tm *= LAM
    rhat = gcd_all(samples)
    return {"cost": cost, "first": first, "rounds": rounds, "rhat": rhat, "ok": rhat == r}

# ---------------- Protocol B -----------------
def protocol_B(inst, rng, s=S, budget_factor=4.0):
    M, r = inst.M, inst.r
    mem_x, mem_v = [], {}            # mem_v: value -> configuration; stored values are distinct by construction
    classes = {}                     # simulator side only: residues represented in the memory
    cost = 0.0; k = 0; level = 0; samples = []; first = None
    def class_size(rho): return len(range(rho if rho > 0 else r, M, r))
    while len(samples) < s:
        target_k = 2 ** level; found_here = False
        while k < target_k and len(samples) < s:              # grow the memory to 2^level distinct values
            xi = int(rng.integers(1, M)); v = inst.f(xi); cost += 1
            if v in mem_v:                                     # repeated value: compatible with the memory, a success
                xj = mem_v[v]
                if xj != xi:
                    samples.append(abs(xi - xj)); found_here = True
                    if first is None: first = cost
                continue
            mem_v[v] = xi; mem_x.append(xi); classes[xi % r] = 1; k += 1
        if len(samples) >= s: break
        rhos = list(classes); weights = np.array([class_size(rho) - 1 for rho in rhos], float)
        mM = weights.sum(); xM = np.sqrt(mM / (M - 1))
        budget = budget_factor * k; spent = 0.0; Tm = 1.0       # horizon reset at each level (Theorem 5.1)
        while spent < budget or (found_here and len(samples) < s):
            tau = rng.uniform(0, Tm); cost += tau + 1; spent += tau   # evolution time plus one classical comparison
            P = two_level_prob(xM, E, tau)
            if rng.random() < P:
                rho = rhos[rng.choice(len(rhos), p=weights / weights.sum())]
                while True:
                    xx = int(rng.integers(0, class_size(rho))) * r + (rho if rho > 0 else r)
                    if xx not in mem_x: break
            else:
                while True:
                    xx = int(rng.integers(1, M))
                    if inst.f(xx) not in mem_v: break
            v = inst.f(xx)
            if v in mem_v and xx not in mem_x:
                samples.append(abs(xx - mem_v[v])); found_here = True
                if first is None: first = cost
                if len(samples) >= s: break
            else:
                Tm *= LAM
        if len(samples) >= s: break
        level += 1
    rhat = gcd_all(samples)
    return {"cost": cost, "first": first, "k": k, "rhat": rhat, "ok": rhat == r}

# ---------------- classical baselines -----------------
def classical_memoryless(inst, rng, s=S):
    p = inst.m / (inst.M - 1); cost = 0; samples = []
    while len(samples) < s:
        n = int(rng.geometric(p)); cost += n; samples.append(int(rng.integers(1, inst.m + 1)) * inst.r)
    rhat = gcd_all(samples); return {"cost": float(cost), "rhat": rhat, "ok": rhat == inst.r}

def classical_birthday(inst, rng, s=S):
    seen = {}; cost = 0; samples = []
    while len(samples) < s:
        xx = int(rng.integers(1, inst.M)); v = inst.f(xx); cost += 1
        if v in seen and seen[v] != xx: samples.append(abs(xx - seen[v]))
        else: seen[v] = xx
    rhat = gcd_all(samples); return {"cost": float(cost), "rhat": rhat, "ok": rhat == inst.r}

# ---------------- Control (i): full state-vector protocol A, no use of r anywhere -----------------
def control_statevector(N, a, M, rng, s=S):
    g = np.array([1 if pow(a, d, N) == 1 else 0 for d in range(1, M)], float)
    Mx = len(g); svec = np.full(Mx, 1 / np.sqrt(Mx)); H = E * (np.diag(g) + np.outer(svec, svec))
    w, V = np.linalg.eigh(H); c0 = V.T @ svec
    m = int(g.sum()); x = np.sqrt(m / Mx)
    # (a) two-level formula vs full evolution
    maxdiff = 0.0
    for tau in np.linspace(0.3, 3 * np.pi / (2 * x), 12):
        psi = V @ (np.exp(-1j * w * tau) * c0); P = float(np.sum(np.abs(psi[g == 1]) ** 2))
        maxdiff = max(maxdiff, abs(P - two_level_prob(x, E, tau)))
    # (b) end-to-end protocol A with genuine measurement sampling from |psi|^2
    Tm = 1.0; cost = 0.0; samples = []
    while len(samples) < s:
        tau = rng.uniform(0, Tm); cost += tau + 1
        psi = V @ (np.exp(-1j * w * tau) * c0); prob = np.abs(psi) ** 2; prob /= prob.sum()
        d = int(rng.choice(Mx, p=prob)) + 1
        if pow(a, d, N) == 1: samples.append(d)
        else: Tm *= LAM
    rhat = gcd_all(samples)
    return {"N": N, "a": a, "M": M, "r_true": order(a, N), "rhat": rhat, "ok": rhat == order(a, N), "max_formula_diff": maxdiff, "cost": cost}

results = {"lambda": LAM, "s": S, "E": E}
# ---- controls
ctrl = []
for (N, a) in [(15, 2), (21, 2), (91, 2), (221, 3), (323, 2)]:
    c = control_statevector(N, a, 2048, rng); ctrl.append(c)
    print(f"control (i) N={N} a={a}: r={c['r_true']} rhat={c['rhat']} ok={c['ok']} max|P_full-P_2level|={c['max_formula_diff']:.1e} cost={c['cost']:.1f}")
ok_ctrl = all(c["ok"] and c["max_formula_diff"] < 1e-9 for c in ctrl)
print("control (i) state-vector end-to-end:", "PASS" if ok_ctrl else "FAIL"); results["control_statevector"] = ctrl
T.lap("controls done")

# ---- scaling runs
targets = [4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536]
inst_list = instances_semiprime(targets); NREP = 24; rows = []
for (N, a, r) in inst_list:
    inst = Instance(N, a, r); row = {"N": N, "a": a, "r": r, "M": inst.M}
    for name, fn in [("A", protocol_A), ("B", protocol_B), ("C1", classical_memoryless), ("C2", classical_birthday)]:
        runs = [fn(inst, rng) for _ in range(NREP)]
        row[name] = {"cost_mean": float(np.mean([u["cost"] for u in runs])), "cost_std": float(np.std([u["cost"] for u in runs])),
                     "success_rate": float(np.mean([u["ok"] for u in runs]))}
        if name in ("A", "B"): row[name]["first_mean"] = float(np.mean([u["first"] for u in runs]))
        if name == "B": row[name]["k_mean"] = float(np.mean([u["k"] for u in runs]))
        if name == "A": row[name]["rounds_mean"] = float(np.mean([u["rounds"] for u in runs]))
    rows.append(row)
    print(f"N={N:6d} a={a:5d} r={r:6d} M=2^{int(np.log2(inst.M))} | A {row['A']['cost_mean']:9.1f} (ok {row['A']['success_rate']:.2f}) | B {row['B']['cost_mean']:9.1f} k={row['B']['k_mean']:.0f} (ok {row['B']['success_rate']:.2f}) | C1 {row['C1']['cost_mean']:10.1f} | C2 {row['C2']['cost_mean']:8.1f}", flush=True)
results["rows"] = rows
T.lap("scaling runs done")

# ---- exponent fits (r >= 64)
fits = {}
rs = np.array([row["r"] for row in rows], float); sel = rs >= 64
for name, expect in [("A", .5), ("B", 1 / 3), ("C1", 1.0), ("C2", .5)]:
    c = np.array([row[name]["cost_mean"] for row in rows]); slope, icpt = np.polyfit(np.log(rs[sel]), np.log(c[sel]), 1)
    fits[name] = {"exponent": float(slope), "prefactor": float(np.exp(icpt)), "expected": expect}
    print(f"fit {name}: cost ~ {np.exp(icpt):.2f} r^{slope:.3f}   (expected exponent {expect:.3f})")
results["fits"] = fits
ok_known = all(row[n]["success_rate"] >= 0.9 for row in rows for n in ("A", "B", "C1", "C2"))
print("control (ii) r recovered in >=90% of runs for every instance and protocol:", "PASS" if ok_known else "FAIL")
results["control_known_answer"] = ok_known; results["control_statevector_pass"] = ok_ctrl
save_json("exp3_protocols.json", results)

fig, ax = plt.subplots(figsize=(5.4, 3.9))
style = {"A": ("o-", "tab:blue", "A: coherent closure loop, predicate access"), "B": ("s-", "tab:red", "B: coherent closure loop, relational memory"),
         "C1": ("^--", "gray", "C1: classical memoryless sampling"), "C2": ("v--", "tab:green", "C2: classical relational memory (birthday)")}
for name in ["C1", "C2", "A", "B"]:
    c = [row[name]["cost_mean"] for row in rows]; mk, col, lab = style[name]
    ax.loglog(rs, c, mk, color=col, ms=4, label=lab + f"  [fit $r^{{{fits[name]['exponent']:.2f}}}$]")
ax.set_xlabel("order $r$"); ax.set_ylabel(f"mean cost to recover $r$ ({S} samples)"); ax.legend(fontsize=7); ax.grid(alpha=.3, which="both")
fig.tight_layout(); fig.savefig(os.path.join(FIGS, "fig3_cost_scaling.pdf")); fig.savefig(os.path.join(FIGS, "fig3_cost_scaling.png"), dpi=150)
T.lap("done; CONTROLS " + ("PASS" if ok_ctrl and ok_known else "FAIL"))
