"""Experiment 4: Fourier readout of the Boolean defect predicate g(s)=[r | s] on Z_M, M = rL.
Prepare sum_s |s>|g(s)>, measure the predicate register, Fourier-transform the first register.
Claim (Lemma): P(nonzero multiple of M/r observed) = (2/r)(1-1/r), i.e. the QFT does not help
for predicate-level access; value-level (r-to-1) access is what Shor's algorithm uses.
"""
import numpy as np, json, os
from common import *
T = Timer("exp4"); rows = []
for (r, L) in [(3, 128), (4, 64), (7, 64), (16, 32), (31, 16), (64, 16), (128, 8)]:
    M = r * L; s = np.arange(M); gb = (s % r == 0).astype(float); tot = 0.0
    for vec in [gb, 1 - gb]:
        pb = vec.sum() / M; psi = vec / np.sqrt(vec.sum()); prob = np.abs(np.fft.fft(psi) / np.sqrt(M)) ** 2
        tot += pb * sum(prob[k] for k in range(1, M) if k % L == 0)
    closed = (2 / r) * (1 - 1 / r); rows.append({"r": r, "M": M, "P_useful": tot, "closed_form": closed})
    print(f"r={r:4d}: P(useful) = {tot:.6f}   (2/r)(1-1/r) = {closed:.6f}")
ok = all(abs(x["P_useful"] - x["closed_form"]) < 1e-10 for x in rows)
print("control: closed form matches to 1e-10:", "PASS" if ok else "FAIL")
save_json("exp4_boolean_qft.json", {"rows": rows, "control": ok}); T.lap("done")

# ---- general window M = 2^n (not a multiple of r): Shor's peak criterion |k/M - j/r| <= 1/(2M), j != 0
print("\nGeneral window M = 2^n, useful = outcome within 1/(2M) of a nonzero j/r (continued-fraction recoverable):")
rows2 = []
for r in [5, 7, 11, 13, 23, 37, 61, 101]:
    n = int(np.ceil(2 * np.log2(r))) + 2; M = 2 ** n; s = np.arange(M); gb = (s % r == 0).astype(float); tot = 0.0
    js = np.round(s * r / M); useful = (np.abs(s / M - js / r) <= 1 / (2 * M)) & (js % r != 0)
    for vec in [gb, 1 - gb]:
        pb = vec.sum() / M; psi = vec / np.sqrt(vec.sum()); prob = np.abs(np.fft.fft(psi) / np.sqrt(M)) ** 2
        tot += pb * prob[useful].sum()
    rows2.append({"r": r, "M": M, "P_useful": tot, "ratio_to_2_over_r": tot * r / 2})
    print(f"r={r:4d} M=2^{n}: P(useful)={tot:.5f}   ratio to 2/r = {tot*r/2:.3f}")
res = json.load(open(os.path.join(RESULTS, "exp4_boolean_qft.json"))); res["general_window"] = rows2
save_json("exp4_boolean_qft.json", res)
