"""Intermediate (partially coherent) regime of the coherent closure loop, on the revised paper's own model.

Model (nongate_order_finding_v3_sn.tex, Sec. 4): configurations d in X={1..M-1}, marked (defect-free) set F={d: r|d},
m=|F|, H = E(Pi_F + |s><s|), |s> uniform, x = sqrt(m/(M-1)).  Interpolating parameter: dephasing rate Gamma.
  local  : dephasing in the configuration basis,  d rho/dt = -i[H,rho] - Gamma (rho - diag rho)
  sector : dephasing between F and its complement, d rho/dt = -i[H,rho] - Gamma [Pi_F,[Pi_F,rho]]  (coherence decays at rate Gamma)
EXACT REDUCTION (permutation symmetry within F and within X\F is preserved by H and by both dephasings):
  rho = 2x2 block sigma on span{|w>,|w_perp>} (bright states) + dark populations D_F, D_C spread uniformly on the
  orthogonal complements inside F and inside X\F. H acts on span{w,w_perp} as E[[1+x^2, xy],[xy, y^2]] and leaves dark
  populations fixed (|s><s| annihilates them, Pi_F is a scalar on each). Local dephasing: sigma_ww -> D_F at rate
  Gamma(1-1/m), sigma_perp,perp -> D_C at rate Gamma(1-1/(M-1-m)), coherence sigma_w,perp decays at rate Gamma.
  Sector dephasing: only sigma_w,perp decays (rate Gamma). P_F = sigma_ww + D_F.
Gamma=0 reproduces Prop 4.1 exactly; Gamma->inf gives the classical sampler P_F = m/(M-1).
Costs in the paper's units: E*tau + 1 predicate evaluation per attempt.
Controls: (C1) reduced dynamics vs full density-matrix RK4 at M=32; (C2) Gamma=0 vs Prop 4.1; (C3) Gamma=inf -> m/(M-1).
"""
import numpy as np, json, time, os
t0 = time.time(); E = 1.0

def reduced_PF(M, r, Gamma, variant, taus):
    m = ((np.arange(1, M) % r) == 0).sum(); n = M - 1; x = np.sqrt(m/n); y = np.sqrt(1 - x*x)
    Hs = E*np.array([[1 + x*x, x*y], [x*y, y*y]])
    if np.isinf(Gamma):
        return np.full(len(taus), m/n), m
    gw = Gamma*(1 - 1/m) if variant == 'local' else 0.0
    gp = Gamma*(1 - 1/(n - m)) if variant == 'local' else 0.0
    gc = Gamma
    # state: sigma (2x2 complex), D_F, D_C
    def rhs(state):
        s = state[:4].reshape(2, 2); DF, DC = state[4].real, state[5].real
        ds = -1j*(Hs@s - s@Hs)
        bw = (Gamma/m) if variant == 'local' else 0.0; bp = (Gamma/(n - m)) if variant == 'local' else 0.0
        ds[0, 0] += -gw*s[0, 0] + bw*DF; ds[1, 1] += -gp*s[1, 1] + bp*DC; ds[0, 1] -= gc*s[0, 1]; ds[1, 0] -= gc*s[1, 0]
        return np.concatenate([ds.reshape(4), [gw*s[0, 0].real - bw*DF, gp*s[1, 1].real - bp*DC]]).astype(complex)
    sig0 = np.array([[x*x, x*y], [x*y, y*y]], dtype=complex)
    st = np.concatenate([sig0.reshape(4), [0, 0]]).astype(complex)
    out = []; t = 0.0; dt = min(0.01, 0.05/max(Gamma, 1.0), 0.05/(E*(1+x)))
    for tau in taus:
        while t < tau - 1e-12:
            h = min(dt, tau - t)
            k1 = rhs(st); k2 = rhs(st + 0.5*h*k1); k3 = rhs(st + 0.5*h*k2); k4 = rhs(st + h*k3)
            st = st + (h/6)*(k1 + 2*k2 + 2*k3 + k4); t += h
        out.append(float(st[0].real + st[4].real))
    return np.array(out), m

def full_PF(M, r, Gamma, variant, taus):
    """control: full density matrix RK4 (small M only)"""
    X = np.arange(1, M); F = (X % r == 0); PiF = np.diag(F.astype(float)); s = np.ones(M-1)/np.sqrt(M-1)
    H = E*(PiF + np.outer(s, s)); rho = np.outer(s, s).astype(complex); Fm = F.astype(float)
    def drho(rho):
        d = -1j*(H@rho - rho@H)
        if variant == 'local': d -= Gamma*(rho - np.diag(np.diag(rho)))
        else:
            C = PiF@rho - rho@PiF; d -= Gamma*(PiF@C - C@PiF)
        return d
    out = []; t = 0.0; dt = min(0.01, 0.05/max(Gamma, 1.0))
    for tau in taus:
        while t < tau - 1e-12:
            h = min(dt, tau - t)
            k1 = drho(rho); k2 = drho(rho + 0.5*h*k1); k3 = drho(rho + 0.5*h*k2); k4 = drho(rho + h*k3)
            rho = rho + (h/6)*(k1 + 2*k2 + 2*k3 + k4); t += h
        out.append(float(np.real(np.sum(np.diag(rho)*Fm))))
    return np.array(out)

def loop_cost(taus, PF, rng, nrep=2000, lam=6/5, T0=1.0, Tcap=None):
    """paper's adaptive loop for ONE defect-free sample: tau ~ U[0,T]; success w.p. PF(tau); on failure T *= lam.
       Tcap: horizon cap (the known coherence time 2/Gamma); Tcap=0 means classical sampling at tau=0."""
    Tmax = taus[-1] if Tcap is None else min(taus[-1], Tcap)
    costs = np.empty(nrep)
    for i in range(nrep):
        T = min(T0, Tmax); c = 0.0
        while True:
            tau = rng.uniform(0, T) if T > 0 else 0.0; p = np.interp(tau, taus, PF); c += E*tau + 1.0
            if rng.uniform() < p: break
            T = min(T*lam, Tmax)
        costs[i] = c
    return float(costs.mean()), float(costs.std()/np.sqrt(nrep))

if __name__ == "__main__":
    rng = np.random.default_rng(1); res = {}
    # ---- controls
    print("CONTROLS")
    reduced_full_diffs = []
    for variant in ['local', 'sector']:
        for G in [0.0, 0.3]:
            M, r = 32, 4; m = ((np.arange(1, M) % r) == 0).sum(); x = np.sqrt(m/(M-1)); taus = np.linspace(0, 3*np.pi/(2*E*x), 60)
            a, _ = reduced_PF(M, r, G, variant, taus); b = full_PF(M, r, G, variant, taus)
            diff = float(np.max(np.abs(a-b))); reduced_full_diffs.append(diff)
            print("  C1 reduced vs full density matrix  M=32 r=4 %-6s Gamma=%.1f : max|dP| = %.1e" % (variant, G, diff))
    M, r = 256, 16; m = ((np.arange(1, M) % r) == 0).sum(); x = np.sqrt(m/(M-1)); taus = np.linspace(0, 3*np.pi/(2*E*x), 200)
    a, _ = reduced_PF(M, r, 0.0, 'local', taus); f = np.sin(E*x*taus)**2 + x**2*np.cos(E*x*taus)**2
    unitary_diff = float(np.max(np.abs(a-f)))
    print("  C2 Gamma=0 vs Prop 4.1 formula (M=256, r=16): max|dP| = %.1e" % unitary_diff)
    a, _ = reduced_PF(M, r, 200.0, 'local', taus)
    classical_diff = float(abs(a[-1] - m/(M-1)))
    print("  C3 Gamma=200 (local) vs classical m/(M-1)=%.4f: P_F(tau_end) = %.4f  [%.0fs]" % (m/(M-1), a[-1], time.time()-t0))
    res["_controls"] = {
        "reduced_full_max": max(reduced_full_diffs),
        "unitary_formula_max": unitary_diff,
        "large_gamma_error": classical_diff,
        "pass": max(reduced_full_diffs) < 1e-10 and unitary_diff < 1e-8 and classical_diff < 1e-4,
    }
    # ---- scan
    M = 4096
    rs = [8, 32, 128, 512]
    Gammas = [0.0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, np.inf]
    for variant in ['local', 'sector']:
        print("\n==== dephasing variant: %s   (M=%d; costs = E*tau + 1 per attempt; E=1) ====" % (variant, M))
        print("   r    m   Gamma    P_F max  tau(max)  C*(known r)   loop(unknown r)   loop, horizon<=2/Gamma   classical (M-1)/m   gain=classical/C*")
        for r in rs:
            m = ((np.arange(1, M) % r) == 0).sum(); n = M-1; x = np.sqrt(m/n)
            taus = np.linspace(0, 8*np.pi/(2*E*x), 800)
            for G in Gammas:
                PF, _ = reduced_PF(M, r, G, variant, taus)
                Carr = (E*taus + 1.0)/np.maximum(PF, 1e-12); k = int(np.argmin(Carr)); Cs = float(Carr[k])
                lc, le = loop_cost(taus, PF, rng)
                cap = (0.0 if np.isinf(G) else (None if G == 0 else 2.0/G))
                lcc, lce = loop_cost(taus, PF, rng, Tcap=cap)
                res["%s|r=%d|Gamma=%s" % (variant, r, G)] = dict(m=int(m), PFmax=float(PF.max()), tau_max=float(taus[np.argmax(PF)]),
                                                                Cstar=Cs, tau_star=float(taus[k]), loop=lc, loop_err=le, loop_capped=lcc, loop_capped_err=lce, classical=n/m)
                print("  %4d %4d  %-6s  %7.4f  %7.2f   %9.1f      %8.1f +- %4.1f    %8.1f +- %4.1f        %8.1f          %6.2f" %
                      (r, m, ("inf" if np.isinf(G) else "%.2f" % G), PF.max(), taus[np.argmax(PF)], Cs, lc, le, lcc, lce, n/m, (n/m)/Cs))
            print("      [%.0fs]" % (time.time()-t0))
    os.makedirs("results", exist_ok=True)
    output_path = os.path.join("results", "exp5_dephasing.json")
    with open(output_path, "w") as handle:
        json.dump(res, handle, indent=1)
    print("\nsaved %s  [%.0fs]" % (output_path, time.time()-t0))
