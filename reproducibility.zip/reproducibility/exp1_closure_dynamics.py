"""Experiment 1: class-level closure-selection dynamics.
(a) hand example of the submitted manuscript (r=4, gamma=log3, kappa=1): Q1=1/2, Q2=27/34  [known-answer control]
(b) convergence from the uniform start for r = 4 ... 65536 at fixed (gamma,beta): steps ~ log r / Lambda
(c) bistability for beta>gamma: basin threshold Q* = (e^beta-e^gamma)/((e^beta-1)(e^gamma+1))  [2-class]
"""
import numpy as np, json
from common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
T = Timer("exp1")

def step(P, D, gamma, kappa):
    w = np.exp(-gamma * D) * (1 + kappa * P); return P * w / np.sum(P * w)

res = {}
# (a) known-answer control
D = np.array([0, 1, 1, 1.]); P = np.full(4, .25); Q = []
for t in range(3): P = step(P, D, np.log(3), 1.0); Q.append(P[0])
res["hand_example"] = {"Q1": Q[0], "Q2": Q[1], "Q2_exact": 27/34}
ok_a = abs(Q[0] - .5) < 1e-12 and abs(Q[1] - 27/34) < 1e-12
print("control (a) hand example:", "PASS" if ok_a else "FAIL", Q[:2])

# (b) convergence vs r
gamma, beta = np.log(3), np.log(2); kappa = np.exp(beta) - 1
curves = {}; steps99 = {}
for k in [2, 4, 8, 12, 16]:
    r = 2 ** k; D = np.zeros(r); D[1:] = 1; P = np.full(r, 1 / r); traj = [P[0]]
    Lam = gamma - np.log(1 + kappa / (r - 1))
    while P[0] < 0.99 and len(traj) < 500:
        P = step(P, D, gamma, kappa); traj.append(P[0])
    curves[r] = traj; steps99[r] = len(traj) - 1
    bound = np.ceil((np.log(r - 1) + np.log(99)) / Lam)
    print(f"r=2^{k}: steps to P0>=0.99 = {steps99[r]}, corollary bound = {int(bound)}, Lambda={Lam:.4f}")
res["convergence"] = {"gamma": gamma, "beta": beta, "steps99": {str(r): s for r, s in steps99.items()},
                      "bound": {str(r): int(np.ceil((np.log(r-1)+np.log(99))/(gamma-np.log(1+kappa/(r-1))))) for r in steps99}}
ok_b = all(steps99[r] <= res["convergence"]["bound"][str(r)] for r in steps99)
print("control (b) steps within corollary bound:", "PASS" if ok_b else "FAIL")

# (c) basin threshold, 2-class reduction
def step2(Q, g, k):
    n0 = Q * (1 + k * Q); n1 = (1 - Q) * np.exp(-g) * (1 + k * (1 - Q)); return n0 / (n0 + n1)
beta_c = np.log(6); gs = np.linspace(0.05, beta_c - 0.02, 40); Qstar = []; Qnum = []
for g in gs:
    k = np.exp(beta_c) - 1; Qs = (np.exp(beta_c) - np.exp(g)) / ((np.exp(beta_c) - 1) * (np.exp(g) + 1)); Qstar.append(Qs)
    lo, hi = 1e-6, 1 - 1e-6
    for _ in range(60):           # bisection on the numerically observed basin boundary
        mid = (lo + hi) / 2; Q = mid
        for _ in range(4000): Q = step2(Q, g, k)
        if Q > .5: hi = mid
        else: lo = mid
    Qnum.append((lo + hi) / 2)
Qstar = np.array(Qstar); Qnum = np.array(Qnum)
ok_c = np.max(np.abs(Qstar - Qnum)) < 1e-6
print("control (c) basin threshold closed form vs bisection: max|diff| = %.2e" % np.max(np.abs(Qstar-Qnum)), "PASS" if ok_c else "FAIL")
res["basin"] = {"beta": beta_c, "gamma": gs.tolist(), "Qstar_closed_form": Qstar.tolist(), "Qstar_numerical": Qnum.tolist()}
res["controls"] = {"hand_example": ok_a, "bound": ok_b, "basin": ok_c}
save_json("exp1_closure_dynamics.json", res)

fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.5))
for r, tr in curves.items(): ax[0].plot(range(len(tr)), tr, marker="o", ms=3, label=f"$r={r}$")
ax[0].set_xlabel("closure-selection step $t$"); ax[0].set_ylabel("target-sector mass $P_0^{(t)}$")
ax[0].set_title(r"(a) convergence, $\gamma=\ln 3$, $\beta=\ln 2$"); ax[0].legend(fontsize=8, ncol=2); ax[0].set_xlim(0, 22)
ax[1].plot(gs, Qstar, "k-", label="closed form $Q^*(\\gamma)$"); ax[1].plot(gs, Qnum, "r.", ms=5, label="numerical basin boundary")
ax[1].axvline(beta_c, ls="--", c="gray"); ax[1].text(beta_c - 0.02, 0.5, r"$\gamma=\beta$", rotation=90, va="center", ha="right")
ax[1].fill_between(gs, Qstar, 1, color="tab:green", alpha=.12); ax[1].fill_between(gs, 0, Qstar, color="tab:red", alpha=.12)
ax[1].text(0.6, 0.55, "target sector wins", color="tab:green"); ax[1].text(0.15, 0.05, "wrong sector wins", color="tab:red")
ax[1].set_xlabel(r"defect penalty $\gamma$"); ax[1].set_ylabel("initial target mass $Q_0$"); ax[1].set_title(r"(b) basin boundary, $\beta=\ln 6$, two classes")
ax[1].legend(fontsize=8, loc="upper left"); ax[1].set_ylim(0, 1)
fig.tight_layout(); fig.savefig(os.path.join(FIGS, "fig1_closure_dynamics.pdf")); fig.savefig(os.path.join(FIGS, "fig1_closure_dynamics.png"), dpi=150)
T.lap("done; ALL CONTROLS " + ("PASS" if ok_a and ok_b and ok_c else "FAIL"))
