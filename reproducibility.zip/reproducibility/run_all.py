"""Run every experiment in order and print a PASS/FAIL summary. Usage:  python3 run_all.py"""
import subprocess, sys, json, os
here = os.path.dirname(os.path.abspath(__file__)); os.chdir(here)
for script in ["exp1_closure_dynamics.py", "exp2_diagonal_filter.py", "exp3_protocols.py", "exp4_boolean_qft.py", "exp5_dephasing.py", "plot_dephasing.py"]:
    print("=" * 70 + f"\n{script}\n" + "=" * 70, flush=True)
    if subprocess.call([sys.executable, script]) != 0: print("FAILED:", script); sys.exit(1)
R = lambda n: json.load(open(os.path.join("results", n)))
c1 = R("exp1_closure_dynamics.json")["controls"]; c2 = R("exp2_diagonal_filter.json")["control_bound"]
e3 = R("exp3_protocols.json"); c4 = R("exp4_boolean_qft.json")["control"]
c5 = R("exp5_dephasing.json")["_controls"]
print("\nSUMMARY OF CONTROLS")
print(" exp1 hand example / corollary bound / basin closed form :", c1)
print(" exp2 acceptance <= bound                                 :", c2)
print(" exp3 state-vector control / known-answer                 :", e3["control_statevector_pass"], e3["control_known_answer"])
print(" exp3 fitted exponents                                    :", {k: round(v["exponent"], 3) for k, v in e3["fits"].items()})
print(" exp4 Boolean-QFT lemma                                   :", c4)
print(" exp5 reduced/full, unitary, classical limits             :", c5)
print("ALL PASS" if all([*c1.values(), c2, e3["control_statevector_pass"], e3["control_known_answer"], c4, c5["pass"]]) else "SOME CONTROL FAILED")
