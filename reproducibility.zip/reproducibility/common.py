"""Shared utilities for the closure-selection order-finding SI code.
All modules use only relative paths; run from the si_code directory (see README.md).
"""
import numpy as np, math, json, os, time

RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
FIGS    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figs")
os.makedirs(RESULTS, exist_ok=True); os.makedirs(FIGS, exist_ok=True)

def save_json(name, obj):
    with open(os.path.join(RESULTS, name), "w") as f: json.dump(obj, f, indent=1, default=float)

def order(a, N):
    """Brute-force multiplicative order of a mod N (used only to build instances / verify answers)."""
    x = 1
    for d in range(1, N):
        x = x * a % N
        if x == 1: return d
    raise ValueError("a not invertible mod N")

def is_prime(n):
    if n < 2: return False
    for p in range(2, int(n**0.5) + 1):
        if n % p == 0: return False
    return True

def instances(target_orders, Nmax=60000, seed=1):
    """Semiprime instances N=pq, a coprime, with orders spanning the requested list (nearest available)."""
    rng = np.random.default_rng(seed)
    primes = [p for p in range(3, 400) if is_prime(p)]
    pool = {}
    for _ in range(20000):
        p, q = rng.choice(primes, 2, replace=False)
        N = int(p * q)
        if N > Nmax: continue
        a = int(rng.integers(2, N - 1))
        if math.gcd(a, N) != 1: continue
        r = order(a, N)
        pool.setdefault(r, (N, a))
    out = []
    keys = np.array(sorted(pool))
    for rt in target_orders:
        r = int(keys[np.argmin(np.abs(np.log(keys) - np.log(rt)))])
        if all(r != o[2] for o in out):
            N, a = pool[r]; out.append((N, a, r))
    return out

def two_level_prob(x, E, tau):
    """Probability of the marked set after evolving |s> under H=E(Pi+|s><s|) for time tau; x^2 = marked fraction."""
    return np.sin(E * x * tau) ** 2 + x ** 2 * np.cos(E * x * tau) ** 2

class Timer:
    def __init__(self, label): self.label = label; self.t0 = time.time()
    def lap(self, msg=""):
        print(f"[{self.label}] {time.strftime('%H:%M:%S')} +{time.time()-self.t0:7.1f}s {msg}", flush=True)
