"""Regenerate Fig. 4 from results/exp5_dephasing.json."""
import json
import os
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, "results", "exp5_dephasing.json")) as handle:
    data = json.load(handle)

rates = [0.0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0]
xrates = np.array([0.004 if g == 0 else g for g in rates])
orders = [8, 32, 128, 512]
colors = ["tab:blue", "tab:orange", "tab:green", "tab:red"]

fig, axes = plt.subplots(2, 2, figsize=(12.8, 9.6), sharex="col")
for col, variant in enumerate(["local", "sector"]):
    top, bottom = axes[0, col], axes[1, col]
    for r, color in zip(orders, colors):
        rows = [data[f"{variant}|r={r}|Gamma={g}"] for g in rates]
        cstar = np.array([row["Cstar"] for row in rows])
        capped = np.array([row["loop_capped"] for row in rows])
        classical = rows[0]["classical"]
        top.loglog(xrates, cstar, "o-", color=color, ms=4, label=f"r={r}: $C^*$ (known r)")
        top.loglog(xrates, capped, "s--", color=color, alpha=0.7, ms=4,
                   label=f"r={r}: closure loop, horizon $\\leq 2/\\Gamma$")
        top.axhline(classical, color=color, linestyle=":", linewidth=1)
        bottom.loglog(xrates, classical / cstar, "o-", color=color, ms=4, label=f"r={r}")
    top.set_title(f"{variant} dephasing: cost vs $\\Gamma$  (dotted = classical)")
    top.set_ylabel("cost per defect-free sample (predicate units)")
    top.grid(alpha=0.3, which="both")
    top.legend(fontsize=6.5, ncol=2)
    bottom.set_title(f"{variant} dephasing: gain over classical sampling")
    bottom.set_xlabel("dephasing rate $\\Gamma/E$  (leftmost point: $\\Gamma=0$)")
    bottom.set_ylabel("gain = classical cost / $C^*$")
    bottom.grid(alpha=0.3, which="both")
    bottom.legend(fontsize=7)

guide = np.logspace(-1.5, 0.2, 100)
for ax in axes[1]:
    ax.loglog(guide, 0.5 / guide, "k--", linewidth=1, label="coherence-horizon law")
    ax.loglog(guide, 1.0 / guide, "k:", linewidth=1)
    ax.set_ylim(0.8, 30)

fig.suptitle("Closure selection between its coherent and classical endpoints", fontsize=12)
fig.tight_layout(rect=(0, 0, 1, 0.97))
os.makedirs(os.path.join(HERE, "figs"), exist_ok=True)
out = os.path.join(HERE, "figs", "fig4_dephasing_interpolation.png")
fig.savefig(out, dpi=180)
print("saved", out)
